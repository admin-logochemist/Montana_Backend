module.exports = {
    UserModel: require("./user"),
    ContactModel: require("./contact"),
    DemoUserModel: require("./demoUser")
};
