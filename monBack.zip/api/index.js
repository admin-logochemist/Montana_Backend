// api/myFunction.js

const app=require('../src/index')
export default app

